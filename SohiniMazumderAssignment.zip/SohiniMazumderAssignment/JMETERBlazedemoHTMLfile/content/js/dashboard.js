/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.25373134328358, "KoPercent": 0.746268656716418};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.3402777777777778, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "https://blazedemo.com/"], "isController": false}, {"data": [0.1111111111111111, 500, 1500, "https://blazedemo.com/-5"], "isController": false}, {"data": [0.65, 500, 1500, "https://blazedemo.com/reserve.php-0"], "isController": false}, {"data": [0.0, 500, 1500, "https://blazedemo.com/-4"], "isController": false}, {"data": [0.0, 500, 1500, "https://blazedemo.com/-3"], "isController": false}, {"data": [0.0, 500, 1500, "https://blazedemo.com/-2"], "isController": false}, {"data": [0.65, 500, 1500, "https://blazedemo.com/reserve.php-3"], "isController": false}, {"data": [0.1111111111111111, 500, 1500, "https://blazedemo.com/-1"], "isController": false}, {"data": [0.65, 500, 1500, "https://blazedemo.com/reserve.php-4"], "isController": false}, {"data": [0.0, 500, 1500, "https://blazedemo.com/-0"], "isController": false}, {"data": [0.9, 500, 1500, "https://blazedemo.com/reserve.php-1"], "isController": false}, {"data": [0.7, 500, 1500, "https://blazedemo.com/reserve.php-2"], "isController": false}, {"data": [0.75, 500, 1500, "https://blazedemo.com/reserve.php-5"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.4, 500, 1500, "https://blazedemo.com/reserve.php"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 134, 1, 0.746268656716418, 8857.425373134325, 77, 66228, 2827.5, 26744.0, 54802.25, 65245.20000000002, 1.8559556786703602, 79.26189729051247, 1.8048281682825484], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://blazedemo.com/", 10, 1, 10.0, 38975.5, 12322, 66228, 32573.5, 65613.5, 66228.0, 66228.0, 0.15061601951983614, 37.97015143499412, 0.4148706490797361], "isController": false}, {"data": ["https://blazedemo.com/-5", 9, 0, 0.0, 8631.666666666666, 313, 12826, 10617.0, 12826.0, 12826.0, 12826.0, 0.37253197566124424, 1.4795776806780083, 0.19099539767788404], "isController": false}, {"data": ["https://blazedemo.com/reserve.php-0", 10, 0, 0.0, 635.8000000000001, 415, 861, 691.0, 851.2, 861.0, 861.0, 0.18652192565236045, 1.0643043081901777, 0.11165814494618842], "isController": false}, {"data": ["https://blazedemo.com/-4", 9, 0, 0.0, 14169.777777777777, 2909, 32321, 11978.0, 32321.0, 32321.0, 32321.0, 0.26967908189254786, 33.385164232688105, 0.13773648420879156], "isController": false}, {"data": ["https://blazedemo.com/-3", 9, 0, 0.0, 16495.666666666668, 2726, 56663, 8631.0, 56663.0, 56663.0, 56663.0, 0.15743348435286092, 6.071028740357199, 0.08056166582119055], "isController": false}, {"data": ["https://blazedemo.com/-2", 9, 0, 0.0, 14563.777777777777, 2805, 63420, 9220.0, 63420.0, 63420.0, 63420.0, 0.14191106906338694, 4.016332707544938, 0.07234138481551561], "isController": false}, {"data": ["https://blazedemo.com/reserve.php-3", 10, 0, 0.0, 820.4, 294, 3958, 556.5, 3635.800000000001, 3958.0, 3958.0, 0.18763838330768942, 0.7526058280481855, 0.11934460844560364], "isController": false}, {"data": ["https://blazedemo.com/-1", 9, 0, 0.0, 20961.777777777777, 332, 54182, 15285.0, 54182.0, 54182.0, 54182.0, 0.16457895218067112, 13.497563460043887, 0.08695040344701471], "isController": false}, {"data": ["https://blazedemo.com/reserve.php-4", 10, 0, 0.0, 1337.6000000000001, 296, 6798, 439.5, 6450.200000000001, 6798.0, 6798.0, 0.18759614302329944, 2.351546964694406, 0.1192994222038795], "isController": false}, {"data": ["https://blazedemo.com/-0", 9, 0, 0.0, 5931.333333333333, 2640, 15744, 3359.0, 15744.0, 15744.0, 15744.0, 0.5456529647144416, 1.7200857129865406, 0.2658992474536195], "isController": false}, {"data": ["https://blazedemo.com/reserve.php-1", 10, 0, 0.0, 412.40000000000003, 77, 3085, 106.5, 2799.300000000001, 3085.0, 3085.0, 0.18908595847672352, 1.5863093198105358, 0.11725545276632757], "isController": false}, {"data": ["https://blazedemo.com/reserve.php-2", 10, 0, 0.0, 1066.7, 298, 6079, 446.5, 5600.800000000002, 6079.0, 6079.0, 0.18851918182675087, 0.562703983645961, 0.11953662574229428], "isController": false}, {"data": ["https://blazedemo.com/reserve.php-5", 10, 0, 0.0, 680.8, 294, 2958, 315.0, 2750.2000000000007, 2958.0, 2958.0, 0.18758910482479177, 0.10335720013881594, 0.11933158484655211], "isController": false}, {"data": ["Test", 10, 1, 10.0, 41057.2, 13517, 67488, 36871.5, 66874.0, 67488.0, 67488.0, 0.14752308736317232, 42.232373526613166, 0.9611763029976691], "isController": true}, {"data": ["https://blazedemo.com/reserve.php", 10, 0, 0.0, 2081.7, 750, 7514, 1259.5, 7203.100000000001, 7514.0, 7514.0, 0.18457335868140792, 6.308227126746525, 0.6941688661658576], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 1, 100.0, 0.746268656716418], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 134, 1, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 1, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["https://blazedemo.com/", 10, 1, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
