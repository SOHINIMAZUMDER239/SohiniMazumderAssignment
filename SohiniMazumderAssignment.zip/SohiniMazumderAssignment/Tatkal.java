package Code;


import org.openqa.selenium.WebDriver;
import java.awt.Robot;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.apache.commons.mail.*;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.SimpleEmail;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.MultiPartEmail;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Tatkal {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	try {

		System.setProperty("webdriver.chrome.driver","C:\\Users\\CODECLOUDS-SOHINI\\Downloads\\Sohini\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-notifications");
		WebDriver driver = new ChromeDriver(options);
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofMillis(200));
		
	
		JavascriptExecutor js = (JavascriptExecutor) driver;

		driver.manage().window().maximize(); // Maximizing the window
		driver.manage().deleteAllCookies(); //deleting all cookies

		driver.get("https://www.irctc.co.in/nget/train-search");// Get the URL of a webpage
		System.out.println(driver.getTitle());
		
		driver.findElement(By.xpath("//button[@aria-label='Confirmation. Get your favourite food at your train seat through <a class=\"txt-msg-info\" target=\"_blank\" href=\"https://www.ecatering.irctc.co.in/\">e-Catering</a> available at selected stations.<br/><br/>COVID 19 Alert:<br/><br/><i class=\"fa fa-circle\" ></i> All passengers are advised to wear face covers/masks at the entry/exit and during travel.<br/><br/><i class=\"fa fa-circle\" ></i> All passengers are advised that on arrival at their destination, the travelling passenger shall follow the Covid protocol/guidelines issued by Ministry of Home affairs, Ministry of Health and Family Welfare and concerned State/UTs on the subject from time to time.<br/><br/><i class=\"fa fa-circle\" ></i><a class=\"txt-msg-info\"target=\"_blank\"href=\"http://contents.irctc.co.in/en/CovidVaccinationInfoEng.pdf\"> Information on Covid 19 Vaccination Programme</a>. Press OK to confirm']")).click();
		
		driver.findElement(By.xpath("//input[@class='ng-tns-c58-8 ui-inputtext ui-widget ui-state-default ui-corner-all ui-autocomplete-input ng-star-inserted']")).sendKeys("CSTM");
		
		
		WebElement from = driver.findElement((By.xpath("//span[contains(text(),'C SHIVAJI MAH T - CSTM')]"))); 
		from.click();
		
		
		
		driver.findElement(By.xpath("//input[@class='ng-tns-c58-9 ui-inputtext ui-widget ui-state-default ui-corner-all ui-autocomplete-input ng-star-inserted']")).sendKeys("HWH");
		Thread.sleep(4000);
		
		WebElement To = driver.findElement((By.xpath("//li[@id='p-highlighted-option']"))); 
		To.click();
		
		
		driver.findElement((By.xpath("//span[@class='ui-dropdown-trigger-icon ui-clickable ng-tns-c66-12 pi pi-chevron-down']"))).click(); 
		
		driver.findElement((By.xpath("//span[normalize-space()='TATKAL']"))).click(); 
		
		
		driver.findElement((By.xpath("//input[@class='ng-tns-c59-10 ui-inputtext ui-widget ui-state-default ui-corner-all ng-star-inserted']"))).click(); 
		
		
		driver.findElement((By.xpath("//a[@class='ui-state-default ng-tns-c59-10 ng-star-inserted']"))).click(); 
		
		
		driver.findElement((By.xpath("//div[@class='ng-tns-c66-11 ui-dropdown ui-widget ui-state-default ui-corner-all']"))).click(); 
		
		
		driver.findElement((By.xpath("//span[normalize-space()='AC 3 Tier (3A)']"))).click();
		
		
		driver.findElement((By.xpath("//label[@for='availableBerth']"))).click();
		
		
		driver.findElement((By.xpath("//button[@type='submit']"))).click();
		
		
		WebDriverWait wait2=new WebDriverWait(driver,Duration.ofSeconds(1, 1));
		WebElement link=wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@aria-label='Click here to Login in application']")));
		link.click();
		
		

	}

	catch (Exception e) {
		System.out.println("Error occured" + e.getMessage());
	}

}}





