package Code;

import org.openqa.selenium.WebDriver;
import java.awt.Robot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.apache.commons.mail.*;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.SimpleEmail;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.MultiPartEmail;
import java.util.ArrayList;
import java.util.List;


public class Selenium {
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws EmailException {
		// TODO Auto-generated method stub



			
			System.out.println("===Test for Sending CommonsEmail started===");  
	        // Create the attachment
	        EmailAttachment attachment = new EmailAttachment();
	        attachment.setPath("C:\\Users\\CODECLOUDS-SOHINI\\Desktop\\Rose.jpg");
	        attachment.setDisposition(EmailAttachment.ATTACHMENT);
	        attachment.setDescription("Picture of Rose");
	        attachment.setName("Rose");
	        // Create the email message
	        MultiPartEmail email = new MultiPartEmail();
	        email.setHostName("smtp.gmail.com");
	        email.setSmtpPort(993);
	        email.setAuthenticator(new DefaultAuthenticator("sohinimazumder2000@gmail.com", "Admin!123"));
	        email.setSSLOnConnect(true);
	        email.setFrom("CommonsEmail@gmail.com");
	        email.setSubject("Uploaded a file");
	        email.setMsg("Kindly find my uploaded file attached herewith for your reference");
	        email.addTo("sohinimazumder2000@gmail.com");
	        // add the attachment
	        email.attach(attachment);
	        // send the email
	        email.send();
	        System.out.println("===Test for Sending CommonsEmail ended===");
	        
	        
			try {
	        
			
			
				
			System.setProperty("webdriver.chrome.driver","C:\\Users\\CODECLOUDS-SOHINI\\Downloads\\sohini\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			
			
			JavascriptExecutor js = (JavascriptExecutor) driver;

			driver.manage().window().maximize(); // Maximizing the window
			driver.manage().deleteAllCookies(); //deleting all cookies

			driver.get("https://support.google.com/mail/answer/8494?hl=en&co=GENIE.Platform%3DDesktop");// Get the URL of a webpage
			System.out.println(driver.getTitle());
			
            
			driver.findElement(By.xpath("//a[@class='gb_1 gb_2 gb_7d gb_7c']")).click();
			
			driver.findElement(By.xpath("//input[@id='identifierId']")).sendKeys("sohinimazumder2000@gmail.com");
			
			driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();
			
			driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Admin!123");
			
			driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();
			
			WebElement Element=driver.findElement(By.xpath("//a[@class='action-button']"));
			
			
			js.executeScript("window.scrollBy(0,600)");
			
			Element.click();
			
			
			WebElement profilelogo=driver.findElement(By.xpath("//img[@class='gb_Ba gbii']"));
			List<WebElement> inboxmessagethread=driver.findElements(By.xpath("//span[@class='bqe']"));
			
			
			if(profilelogo.isDisplayed())
			{
			
			
			for(int i=0; i < inboxmessagethread.size(); i++)
			{
				if(inboxmessagethread.get(i).getText().contains("Uploaded a file"))
				{
					inboxmessagethread.get(i).click();
					break;
				}
				}
			System.out.println("click on any inbox message to see the uploaded file's contents");
			}
			
}
			
			catch (Exception e) {
				System.out.println("Error occured" + e.getMessage());
			}
	}}
				
			
			
